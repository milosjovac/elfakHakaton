<?php

echo "Hello world";

?>