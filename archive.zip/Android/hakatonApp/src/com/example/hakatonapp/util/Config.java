package com.example.hakatonapp.util;

public class Config {

	public static final String FEED_URL = "";

}
