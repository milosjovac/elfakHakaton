package com.example.hakatonapp.fragments;

public class StudyBuddyFragment {

}
