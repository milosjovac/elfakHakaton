package com.example.hakatonapp.data;

import org.json.JSONArray;

public class Profile {

	String name;
	String email;
	String imageUrl;

}
