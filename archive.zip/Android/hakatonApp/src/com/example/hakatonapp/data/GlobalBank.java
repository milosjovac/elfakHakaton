package com.example.hakatonapp.data;

public class GlobalBank {

}
